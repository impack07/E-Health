package com.mintedcorp.contactapp;


import java.util.ArrayList;
import java.util.List;

public class Contact {

    //All required datas

    private String image;
    private String firstName;
    private String lastName;
    private int number;
    private String id;

    //Getting images, here only 1 image is given all Imageviews
    private static String[] images ={String.valueOf(R.drawable.pic), String.valueOf(R.drawable.pic), String.valueOf(R.drawable.pic), String.valueOf(R.drawable.pic), String.valueOf(R.drawable.pic)};


    public Contact(String id, String image,  String firstName, String lastName, int number) {
        this.id = id;
        this.image = image;
        this.firstName = firstName;
        this.lastName = lastName;
        this.number = number;
    }


    public String getId() { return id; }

    public void setId(String id) { this.id = id;  }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    //Initializing each list item one-by-one,
    // with pics array

    public static List<Contact> getDefaults(){
        List<Contact> result = new ArrayList<>();
        Contact contact = new Contact("0",
                images[0],
                "Ethan",
                "Hund",
                555555
        );
        result.add(contact);

        contact = new Contact("1",
                images[1],
                "Jack",
                "Ryan",
                888888
        );
        result.add(contact);

        contact = new Contact("2",
                images[2],
                "Kanye",
                "West",
                4444444
        );
        result.add(contact);

        contact = new Contact("3",
                images[3],
                "Joe",
                "Doe",
                1111111
        );
        result.add(contact);

        contact = new Contact("4",
                images[4],
                "Luke",
                "Cage",
                999999
        );

        result.add(contact);

        return result;
    }
}

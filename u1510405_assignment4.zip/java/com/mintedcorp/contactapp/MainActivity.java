package com.mintedcorp.contactapp;


import android.content.res.Configuration;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView contactListView;

    private List<Contact> contacts;
    private ContactLister adapter;

    //Check whether orientation
    private boolean isLandscape = false;
    FragmentTransaction manager = getSupportFragmentManager().beginTransaction();

    private Contact_Info   contactInfoFragment = new Contact_Info();;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactListView = findViewById(R.id.list_main);
        contacts = Contact.getDefaults();
        adapter = new ContactLister(MainActivity.this, contacts);
        contactListView.setAdapter(adapter);

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            isLandscape = true;
            manager.add(R.id.list_main, contactInfoFragment).commit();
        }
        else
        {
            manager.replace(R.id.box, contactInfoFragment).commit();
        }

        contactListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Contact contact = contacts.get(i);
                if (isLandscape) {
                    Toast.makeText(MainActivity.this, "Landscape mode", Toast.LENGTH_SHORT).show();

                    contactInfoFragment.setData(contact);
                } else{
                    contactListView.setVisibility(View.GONE);
                    contactInfoFragment.setData(contact);
                }
            }
        });



    }
}

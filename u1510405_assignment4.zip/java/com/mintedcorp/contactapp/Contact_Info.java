package com.mintedcorp.contactapp;


import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class Contact_Info extends Fragment {

    private ImageView imageView;
    private TextView firstName;
    private TextView lastName;
    private TextView phoneNumber;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.contact_info, container, false);

    }

    //Initialize
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {


        super.onViewCreated(view, savedInstanceState);

        firstName = view.findViewById(R.id.firstname_of);
        lastName = view.findViewById(R.id.lastname_of);
        imageView = view.findViewById(R.id.image_of);
        phoneNumber = view.findViewById(R.id.phonenumber_of);
    }

    //Setter
    public void setData(Contact contact){

        imageView.setImageResource(Integer.parseInt(contact.getImage()));
        firstName.setText("FirstName - " + contact.getFirstName());
        lastName.setText("LastName - " + contact.getLastName());
        phoneNumber.setText("Phone number - " + contact.getNumber());
    }
}

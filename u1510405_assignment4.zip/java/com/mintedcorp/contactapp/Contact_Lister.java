package com.mintedcorp.contactapp;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

class ContactLister extends ArrayAdapter {


    //List of all contacts
    private List<Contact> contacts;

    public ContactLister(@NonNull Context context, List<Contact> contacts) {
        super(context, R.layout.contact_item);
        this.contacts = contacts;
    }

    @Override
    public int getCount(){ return contacts.size(); }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        ContactViewHolder holder = new ContactViewHolder();
        Contact contact = contacts.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).
                    inflate(R.layout.contact_item, parent, false);
        }

        holder.titleText = convertView.findViewById(R.id.firstname_item);
        holder.aboutText = convertView.findViewById(R.id.lastname_item);

        holder.setData(contact.getFirstName(), contact.getLastName());
        return convertView;
    }

    private class ContactViewHolder {
        TextView titleText;
        TextView aboutText;

        void setData(String first, String last) {
            titleText.setText(first);
            aboutText.setText(last);
        }
    }
}

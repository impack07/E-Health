/**********

Implemented by:
	Bekzodjon Norkuziev U1510405	15-2 Group
	Beknazar Norkuziev  U1510104	15-2 Group

***********/

Brief information:

	Contact_List app which is built based on ListView, that shows, short info (Name, Surname, and Picture) based on screen orientation.
	Consist of main 4 classes,which is ListView is located in Main Acitivty; Contact  and Contact_lister classes helps 
	to load and initialize main details(Name, Surname, Phone, id, Picture), and pass to the List.



Thank You
	